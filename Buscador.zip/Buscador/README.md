# 🔬 LabSearch Pro (Buscador Demo)

> **Sistema de Búsqueda Contextual y Federada para Gestión de Activos.**

Este repositorio contiene la implementación de referencia de un motor de búsqueda inteligente diseñado para entornos corporativos. A diferencia de un buscador lineal, este sistema implementa lógica de **Búsqueda Federada** (consultar múltiples fuentes simultáneamente) y **Expansión de Contexto** (sugerir activos relacionados automáticamente).

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Stack](https://img.shields.io/badge/stack-MERN%20%2F%20Vite-yellow)
![Status](https://img.shields.io/badge/status-Prototype-green)

---

## 🚀 Características Principales

### 🧠 Backend (Lógica de Negocio)

- **Arquitectura de Orquestador:** El backend actúa como un _hub_ que centraliza peticiones.
- **Búsqueda Federada:** Preparado para consultar múltiples fuentes (S3, APIs externas, BD Legacy) en paralelo usando `Promise.all`.
- **Expansión de Relaciones:** Algoritmo que detecta y sugiere ítems vinculados (ej. Si buscas "Microscopio", sugiere su "Manual" y "Kit de Limpieza").
- **Normalización de Datos (Adapter Pattern):** Estandarización de datos heterogéneos antes de enviarlos al cliente.

### 🎨 Frontend (Experiencia de Usuario)

- **UX Reactiva:** Implementación de _Debounce_ (300ms) para optimizar el rendimiento de red.
- **Smart Highlighting:** Resaltado de texto coincidente mediante expresiones regulares (`RegExp`).
- **Tematización:** Soporte nativo para Modo Claro (Clínico) y Modo Oscuro (Cyberpunk) sin librerías externas.
- **Diseño Responsivo:** Interfaz adaptable tipo Dashboard con barra lateral contextual.

---

## 🛠️ Stack Tecnológico

El proyecto sigue una arquitectura desacoplada para permitir la migración de componentes sin afectar el sistema completo.

- **Backend:** Node.js + Express.
- **Frontend:** React + Vite.
- **Estilos:** CSS-in-JS (Objetos de estilo nativos).
- **Datos:** JSON Mock Data (Simulando NoSQL).

---

## 📂 Estructura del Proyecto

```text
buscadorDemo/
├── client/                 # Frontend (React + Vite)
│   ├── src/
│   │   ├── components/     # SearchEngine, ProductModal, etc.
│   │   ├── hooks/          # useSearch (Lógica de conexión y debounce)
│   │   └── App.jsx
│   └── ...
├── server/                 # Backend (Node + Express)
│   ├── controllers/        # searchController.js (Lógica CORE de búsqueda)
│   ├── data/               # Archivos JSON (Simulación de DB)
│   ├── routes/             # Definición de endpoints
│   └── index.js            # Punto de entrada
└── README.md
```
