/* client/src/components/SearchEngine.jsx */
import React, { useState } from 'react';
import { useSearch } from '../hooks/useSearch';
import { ProductModal } from './ProductModal';

// --- HIGHLIGHTER (Sin cambios) ---
const Highlighter = ({ text, highlight }) => {
  if (!highlight || !text) return <span>{text}</span>;
  const escapedHighlight = highlight.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const parts = text.toString().split(new RegExp(`(${escapedHighlight})`, 'gi'));
  return (
    <span>
      {parts.map((part, i) => 
        part.toLowerCase() === highlight.toLowerCase() ? (
          <span key={i} style={{ backgroundColor: '#ffefc2', color: '#856404', fontWeight: 'bold', borderRadius: '2px', padding: '0 2px' }}>{part}</span>
        ) : part
      )}
    </span>
  );
};

export const SearchEngine = () => {
  const { query, setQuery, category, setCategory, results, related, loading } = useSearch();
  const [selectedItem, setSelectedItem] = useState(null);
  
  // 1. ESTADO DEL MODO OSCURO
  const [isDarkMode, setIsDarkMode] = useState(false);

  // 2. DEFINICIÓN DE TEMAS
  const colors = isDarkMode ? {
    // PALETA DARK (Cyberpunk Lab)
    bg: '#0f172a',           // Azul noche profundo
    cardBg: '#1e293b',       // Pizarra oscuro
    text: '#e2e8f0',         // Blanco humo
    subtext: '#94a3b8',      // Gris azulado
    accent: '#38bdf8',       // Cyan Neón
    border: '#334155',       // Borde sutil
    inputBg: '#1e293b',
    shadow: '0 20px 40px rgba(0, 0, 0, 0.4)',
    sidebarBg: '#1e293b',
    sidebarBorder: '#38bdf8',
    badgeBg: 'rgba(56, 189, 248, 0.1)',
    filterActive: '#38bdf8',
    filterInactive: '#334155',
    filterTextInactive: '#cbd5e1'
  } : {
    // PALETA LIGHT (Pharma Clean)
    bg: '#f0f4f8',
    cardBg: '#ffffff',
    text: '#102a43',
    subtext: '#486581',
    accent: '#00b4d8',
    border: '#e0e6ed',
    inputBg: '#ffffff',
    shadow: '0 20px 40px rgba(0, 0, 0, 0.08)',
    sidebarBg: '#ffffff',
    sidebarBorder: '#00b4d8',
    badgeBg: '#e3f8fa',
    filterActive: '#00b4d8',
    filterInactive: '#d9e2ec',
    filterTextInactive: '#486581'
  };

  const styles = {
    container: {
      minHeight: '100vh', width: '100%', 
      background: colors.bg, color: colors.text,
      fontFamily: "'Segoe UI', Roboto, sans-serif", padding: '40px 60px', boxSizing: 'border-box',
      transition: 'background 0.3s ease, color 0.3s ease' // Transición suave
    },
    topBar: {
      display: 'flex', justifyContent: 'flex-end', marginBottom: '20px'
    },
    themeBtn: {
      background: isDarkMode ? '#fbbf24' : '#475569',
      color: isDarkMode ? '#000' : '#fff',
      border: 'none', padding: '10px 20px', borderRadius: '30px',
      cursor: 'pointer', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '8px',
      boxShadow: '0 4px 12px rgba(0,0,0,0.2)'
    },
    header: { textAlign: 'center', marginBottom: '50px' },
    title: { fontSize: '3rem', color: colors.text, marginBottom: '10px', letterSpacing: '-1.5px', fontWeight: '800' },
    subtitle: { color: colors.subtext, fontWeight: '400', fontSize: '1.2rem' },
    searchContainer: { maxWidth: '900px', margin: '0 auto 40px', position: 'relative' },
    input: {
      width: '100%', padding: '22px 30px', fontSize: '20px', borderRadius: '12px',
      border: `2px solid transparent`, background: colors.inputBg,
      boxShadow: colors.shadow, outline: 'none', transition: 'all 0.3s ease', color: colors.text,
    },
    filters: { display: 'flex', justifyContent: 'center', gap: '20px', marginBottom: '50px' },
    filterBtn: (isActive) => ({
      padding: '12px 30px', borderRadius: '8px', border: 'none', cursor: 'pointer',
      fontWeight: '600', fontSize: '15px', transition: 'all 0.3s ease',
      background: isActive ? colors.filterActive : colors.filterInactive,
      color: isActive ? (isDarkMode ? '#000' : '#fff') : colors.filterTextInactive,
      transform: isActive ? 'translateY(-2px)' : 'none',
      boxShadow: isActive ? `0 4px 12px ${colors.accent}66` : 'none',
    }),
    grid: {
      display: 'grid', gridTemplateColumns: related.length > 0 ? '3fr 1fr' : '1fr',
      gap: '40px', width: '100%', maxWidth: '1800px', margin: '0 auto',
    },
    resultsGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', gap: '25px' },
    card: {
      background: colors.cardBg, borderRadius: '12px', padding: '30px',
      boxShadow: '0 2px 10px rgba(0,0,0,0.05)', border: `1px solid ${colors.border}`,
      transition: 'transform 0.2s, box-shadow 0.2s', cursor: 'pointer',
      height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between'
    },
    badge: {
      display: 'inline-block', background: colors.badgeBg, color: colors.accent,
      padding: '6px 14px', borderRadius: '50px', fontSize: '11px',
      fontWeight: '800', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '15px'
    },
    sidebar: {
      background: colors.sidebarBg, borderRadius: '12px', padding: '30px', height: 'fit-content',
      borderLeft: `5px solid ${colors.sidebarBorder}`, boxShadow: '0 10px 40px rgba(0,0,0,0.1)',
      position: 'sticky', top: '40px', border: `1px solid ${colors.border}`
    },
    tag: {
      color: colors.subtext, fontSize: '12px', marginRight: '10px', 
      background: isDarkMode ? 'rgba(255,255,255,0.05)' : '#f0f4f8', 
      padding: '3px 8px', borderRadius: '4px'
    }
  };

  return (
    <div style={styles.container}>
      
      {/* BOTÓN TOGGLE MODE */}
      <div style={styles.topBar}>
        <button style={styles.themeBtn} onClick={() => setIsDarkMode(!isDarkMode)}>
          {isDarkMode ? '☀️ Modo Día' : '🌙 Modo Noche'}
        </button>
      </div>

      <div style={styles.header}>
        <h1 style={styles.title}>LabSearch <span style={{color: colors.accent}}>Pro</span></h1>
        <p style={styles.subtitle}>Sistema Inteligente de Gestión de Activos</p>
      </div>

      <div style={styles.searchContainer}>
        <input
          style={{ ...styles.input, borderColor: query ? colors.accent : 'transparent' }}
          type="text"
          placeholder="🔍 Buscar reactivos, equipos o documentación..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      <div style={styles.filters}>
        <button style={styles.filterBtn(category === '')} onClick={() => setCategory('')}>Todas las Áreas</button>
        <button style={styles.filterBtn(category === 'instruments')} onClick={() => setCategory('instruments')}>🔬 Instrumentación</button>
        <button style={styles.filterBtn(category === 'products')} onClick={() => setCategory('products')}>📦 Inventario</button>
        <button style={styles.filterBtn(category === 'documents')} onClick={() => setCategory('documents')}>📄 Normativa ISO</button>
      </div>

      {loading && <p style={{ textAlign: 'center', color: colors.accent, fontWeight: 'bold' }}>Procesando solicitud...</p>}

      <div style={styles.grid}>
        <div>
          {results.length > 0 && <h3 style={{ color: colors.subtext, fontSize: '13px', textTransform: 'uppercase', letterSpacing: '1.5px', marginBottom: '25px', borderBottom: `1px solid ${colors.border}`, paddingBottom: '10px' }}>Resultados del Inventario ({results.length})</h3>}
          
          <div style={styles.resultsGrid}>
            {results.map((item) => (
              <div key={item.id} style={styles.card} 
                   onClick={() => setSelectedItem(item)}
                   onMouseEnter={(e) => { e.currentTarget.style.transform = 'translateY(-5px)'; }}
                   onMouseLeave={(e) => { e.currentTarget.style.transform = 'translateY(0)'; }}
              >
                <div>
                  <span style={styles.badge}>{item.category}</span>
                  <h2 style={{ fontSize: '20px', color: colors.text, margin: '0 0 10px 0', fontWeight: '700' }}>
                    <Highlighter text={item.name.es} highlight={query} />
                  </h2>
                  <p style={{ fontSize: '15px', color: colors.subtext, lineHeight: '1.6' }}>
                    <Highlighter text={item.description.es} highlight={query} />
                  </p>
                </div>
                <div style={{ marginTop: '20px', borderTop: `1px solid ${colors.border}`, paddingTop: '15px' }}>
                  {item.tags.map(tag => (
                    <span key={tag} style={styles.tag}>#{tag}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
          
          {results.length === 0 && !loading && query && (
             <div style={{ textAlign: 'center', padding: '50px', color: colors.subtext }}>No se encontraron coincidencias.</div>
          )}
        </div>

        {related.length > 0 && (
          <aside style={styles.sidebar}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '25px' }}>
              <div style={{ width: '40px', height: '40px', background: colors.badgeBg, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: colors.accent, fontSize: '20px' }}>⚡</div>
              <div>
                <h4 style={{ margin: 0, color: colors.text, fontSize: '16px' }}>Contexto Relacionado</h4>
                <span style={{ fontSize: '12px', color: colors.subtext }}>IA Predictiva</span>
              </div>
            </div>
            {related.map((rel) => (
              <div key={rel.id} 
                   onClick={() => setSelectedItem(rel)}
                   style={{ padding: '15px', background: isDarkMode ? 'rgba(255,255,255,0.03)' : '#f7f9fa', borderRadius: '8px', marginBottom: '10px', border: `1px solid ${colors.border}`, cursor: 'pointer' }}>
                <span style={{ fontSize: '10px', fontWeight: 'bold', color: colors.accent, textTransform: 'uppercase', display: 'block', marginBottom: '5px' }}>
                  {rel.category === 'products' ? '🛍️ Requiere Insumo' : '⚠️ Información'}
                </span>
                <p style={{ fontSize: '14px', fontWeight: '600', color: colors.text, margin: 0 }}>
                  <Highlighter text={rel.name.es} highlight={query} />
                </p>
              </div>
            ))}
          </aside>
        )}
      </div>

      {/* 3. PASAMOS EL TEMA A LA MODAL */}
      <ProductModal item={selectedItem} onClose={() => setSelectedItem(null)} isDarkMode={isDarkMode} />
    </div>
  );
};