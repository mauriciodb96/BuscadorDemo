/* client/src/components/ProductModal.jsx */
import React from 'react';

export const ProductModal = ({ item, onClose, isDarkMode }) => {
  if (!item) return null;

  // COLORES DINÁMICOS
  const theme = {
    overlay: isDarkMode ? 'rgba(0, 0, 0, 0.85)' : 'rgba(16, 42, 67, 0.75)',
    bg: isDarkMode ? '#1e293b' : 'white',
    text: isDarkMode ? '#e2e8f0' : '#334e68',
    headerBg: isDarkMode ? '#0f172a' : '#f0f4f8',
    border: isDarkMode ? '#334155' : '#d9e2ec',
    keyText: isDarkMode ? '#94a3b8' : '#627d98',
    valueText: isDarkMode ? '#f1f5f9' : '#102a43'
  };

  const styles = {
    overlay: {
      position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
      backgroundColor: theme.overlay,
      backdropFilter: 'blur(5px)',
      display: 'flex', justifyContent: 'center', alignItems: 'center',
      zIndex: 1000, animation: 'fadeIn 0.2s ease-out'
    },
    modal: {
      backgroundColor: theme.bg,
      color: theme.text,
      width: '90%', maxWidth: '600px', borderRadius: '16px', padding: '0',
      boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
      position: 'relative', overflow: 'hidden', fontFamily: "'Segoe UI', Roboto, sans-serif",
      border: `1px solid ${theme.border}`
    },
    header: {
      background: theme.headerBg,
      padding: '25px 30px',
      borderBottom: `1px solid ${theme.border}`,
      display: 'flex', justifyContent: 'space-between', alignItems: 'center'
    },
    body: { padding: '30px' },
    title: { margin: 0, color: theme.valueText, fontSize: '22px' },
    closeBtn: { background: 'none', border: 'none', fontSize: '24px', cursor: 'pointer', color: theme.keyText },
    metaTable: { width: '100%', borderCollapse: 'collapse', marginTop: '20px', fontSize: '14px' },
    metaRow: { borderBottom: `1px solid ${theme.border}` },
    metaKey: { padding: '10px 0', fontWeight: '600', color: theme.keyText, width: '40%' },
    metaValue: { padding: '10px 0', color: theme.valueText, fontWeight: '500' },
    actionBtn: {
      marginTop: '25px', width: '100%', padding: '15px',
      background: '#00b4d8', color: 'white', border: 'none',
      borderRadius: '8px', fontSize: '16px', fontWeight: 'bold',
      cursor: 'pointer', transition: 'background 0.3s'
    }
  };

  return (
    <div style={styles.overlay} onClick={onClose}>
      <div style={styles.modal} onClick={(e) => e.stopPropagation()}>
        <div style={styles.header}>
          <div>
            <span style={{ fontSize: '10px', textTransform: 'uppercase', letterSpacing: '1px', color: '#00b4d8', fontWeight: 'bold' }}>
              {item.category}
            </span>
            <h2 style={styles.title}>{item.name.es}</h2>
          </div>
          <button style={styles.closeBtn} onClick={onClose}>&times;</button>
        </div>

        <div style={styles.body}>
          <p style={{ lineHeight: '1.6', fontSize: '16px' }}>{item.description.es}</p>
          <table style={styles.metaTable}>
            <tbody>
              <tr style={styles.metaRow}>
                <td style={styles.metaKey}>ID Sistema</td>
                <td style={styles.metaValue}>{item.id}</td>
              </tr>
              {item.metadata && Object.entries(item.metadata).map(([key, value]) => (
                <tr key={key} style={styles.metaRow}>
                  <td style={styles.metaKey}>{key.charAt(0).toUpperCase() + key.slice(1)}</td>
                  <td style={styles.metaValue}>{value}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div style={{ marginTop: '20px' }}>
            {item.tags.map(tag => (
              <span key={tag} style={{ background: isDarkMode ? 'rgba(0, 180, 216, 0.15)' : '#e3f8fa', color: '#00b4d8', padding: '5px 10px', borderRadius: '4px', fontSize: '12px', marginRight: '8px' }}>
                #{tag}
              </span>
            ))}
          </div>
          <button style={styles.actionBtn}>Solicitar Activo</button>
        </div>
      </div>
    </div>
  );
};