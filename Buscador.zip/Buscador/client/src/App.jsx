/* client/src/App.jsx */
import React from 'react';
import { SearchEngine } from './components/SearchEngine';

function App() {
  // Quitamos todos los divs extra y estilos.
  // SearchEngine se encargará de todo el layout.
  return <SearchEngine />;
}

export default App;