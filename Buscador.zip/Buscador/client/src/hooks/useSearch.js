/* src/hooks/useSearch.js */
import { useState, useEffect } from 'react';

export const useSearch = () => {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState(''); // Nuevo estado para filtros
  const [results, setResults] = useState([]);
  const [related, setRelated] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Si no hay texto, limpiamos todo (incluso si hay filtro seleccionado)
    if (!query) {
      setResults([]);
      setRelated([]);
      return;
    }

    const delayDebounceFn = setTimeout(async () => {
      setLoading(true);
      setError(null);
      try {
        // Construimos el filtro JSON para el backend
        // Si category está vacío, no mandamos filtro
        const filterParam = category 
          ? `&filters=${JSON.stringify({ category })}` 
          : '';

        const url = `http://localhost:3001/api/search?q=${query}&lang=es${filterParam}`;
        
        const response = await fetch(url);
        if (!response.ok) throw new Error('Error de conexión');
        
        const data = await response.json();
        
        setResults(data.results || []);
        setRelated(data.related_context || []);
        
      } catch (err) {
        setError(err.message);
        setResults([]);
      } finally {
        setLoading(false);
      }
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [query, category]); // Se ejecuta cuando cambia el texto O la categoría

  return { query, setQuery, category, setCategory, results, related, loading, error };
};