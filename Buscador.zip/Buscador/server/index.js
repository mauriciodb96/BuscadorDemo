/* server/index.js */
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

// 1. IMPORTACIÓN DE DATOS
// Usamos ./ porque el archivo index.js está al mismo nivel que la carpeta data
const instruments = require('./data/instruments.json');
const products = require('./data/products.json');
const documents = require('./data/documents.json');

const app = express();
const PORT = 3001;

// 2. MIDDLEWARES (El orden es CRÍTICO)

// A. CORS: Permite acceso desde cualquier lugar
app.use(cors());

// B. BODY PARSER: Para entender JSON
app.use(bodyParser.json());

// C. HEADERS DE SEGURIDAD MANUALES (Solución definitiva CSP)
app.use((req, res, next) => {
    // Elimina cualquier restricción previa
    res.removeHeader("Content-Security-Policy");
    res.removeHeader("X-Content-Security-Policy");
    
    // Política "Salvaje Oeste": Permite TODO (imágenes, scripts, estilos de cualquier sitio)
    res.setHeader(
        "Content-Security-Policy", 
        "default-src * 'unsafe-inline' 'unsafe-eval' data: blob:; img-src * data: blob: 'unsafe-inline'; script-src * 'unsafe-inline' 'unsafe-eval';"
    );
    next();
});

// D. FAVICON: Evita error 404 silencioso
app.get('/favicon.ico', (req, res) => res.status(204).end());

// 3. CARGA DE DATOS
const MASTER_DATA = [...instruments, ...products, ...documents];

// 4. RUTAS

// A. Ruta Raíz (SOLUCIÓN AL "CANNOT GET /")
// Si entras a localhost:3001, te redirige a /api/health para que veas que funciona
app.get('/', (req, res) => {
    res.redirect('/api/health');
});

// B. Health Check
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        totalItems: MASTER_DATA.length,
        message: 'Search Engine Ready - CORS & CSP Open'
    });
});

// C. Rutas de Búsqueda
app.use('/api/search', require('./routes/searchRoutes')); 

// 5. INICIAR SERVIDOR
app.listen(PORT, () => {
    console.log(`--------------------------------------------------`);
    console.log(`✅ Servidor corriendo en: http://localhost:${PORT}`);
    console.log(`📦 Datos cargados: ${MASTER_DATA.length} items.`);
    console.log(`--------------------------------------------------`);
});