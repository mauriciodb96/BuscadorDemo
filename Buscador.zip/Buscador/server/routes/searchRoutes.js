/* server/routes/searchRoutes.js */
const express = require('express');
const router = express.Router();
const searchController = require('../controllers/searchController');

// Ruta principal de búsqueda
// GET /api/search?q=microscopio&lang=es
router.get('/', searchController.search);

// Ruta para autocompletado/sugerencias
// GET /api/search/suggestions?q=mic&lang=es
router.get('/suggestions', searchController.getSuggestions);

module.exports = router;