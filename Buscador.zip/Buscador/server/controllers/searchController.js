/* server/controllers/searchController.js */

// 1. IMPORTAR DATOS
// (Nota: usa ../ porque el controller está dentro de una carpeta)
const instruments = require('../data/instruments.json');
const products = require('../data/products.json');
const documents = require('../data/documents.json');

// Unificamos toda la data
const ALL_DATA = [...instruments, ...products, ...documents];

// Helper: Buscar por ID
const findById = (id) => ALL_DATA.find(item => item.id === id);

exports.search = (req, res) => {
    try {
        const query = req.query.q ? req.query.q.toLowerCase() : '';
        const lang = req.query.lang || 'es'; 
        const filters = req.query.filters ? JSON.parse(req.query.filters) : {};

        if (!query) {
            return res.json({ results: [], related: [] });
        }

        // --- 1. BÚSQUEDA DIRECTA ---
        let directMatches = ALL_DATA.filter(item => {
            // Protección contra campos nulos (safe navigation)
            const name = item.name && item.name[lang] ? item.name[lang].toLowerCase() : '';
            const desc = item.description && item.description[lang] ? item.description[lang].toLowerCase() : '';
            // Tus tags son arrays de strings simples, esto funcionará bien:
            const tags = item.tags ? item.tags.map(t => t.toLowerCase()) : [];

            return name.includes(query) || 
                   desc.includes(query) || 
                   tags.some(tag => tag.includes(query));
        });

        // --- 2. FILTROS ---
        if (filters.category) {
            directMatches = directMatches.filter(item => item.category === filters.category);
        }
        // Filtro por grupo (Laboratorio A, Mantenimiento, etc.)
        if (filters.group) {
            directMatches = directMatches.filter(item => 
                item.metadata && item.metadata.group === filters.group
            );
        }

        // --- 3. EXPANSIÓN DE RELACIONES (Intelligent Mapping) ---
        let relatedItems = [];
        const processedIds = new Set(directMatches.map(i => i.id)); 

        directMatches.forEach(item => {
            if (item.related_ids && item.related_ids.length > 0) {
                item.related_ids.forEach(relatedId => {
                    if (!processedIds.has(relatedId)) {
                        const found = findById(relatedId);
                        if (found) {
                            relatedItems.push(found);
                            processedIds.add(relatedId);
                        }
                    }
                });
            }
        });

        // --- 4. RESPUESTA ---
        res.json({
            meta: {
                total_direct: directMatches.length,
                total_related: relatedItems.length,
                query: query
            },
            results: directMatches,
            related_context: relatedItems 
        });

    } catch (error) {
        console.error("Search Error:", error);
        res.status(500).json({ error: 'Error processing search' });
    }
};

exports.getSuggestions = (req, res) => {
    const query = req.query.q ? req.query.q.toLowerCase() : '';
    const lang = req.query.lang || 'es';
    
    if (!query) return res.json([]);

    const suggestions = ALL_DATA
        .filter(item => item.name && item.name[lang] && item.name[lang].toLowerCase().includes(query))
        .map(item => ({
            id: item.id,
            name: item.name[lang],
            category: item.category
        }))
        .slice(0, 5); 

    res.json(suggestions);
};